'use client'

import { useState } from 'react'
import { Bell, CalendarDays, ChevronRight, CircleHelp, FilePlus2, Heart, MapPin, Menu, PawPrint, Plus, Search, ShoppingBag, ShieldCheck, Sparkles, X } from 'lucide-react'

const navItems = [
  { label: 'Overview', icon: PawPrint },
  { label: 'My pets', icon: Heart },
  { label: 'Community posts', icon: FilePlus2 },
  { label: 'Shop PetVerse', icon: ShoppingBag },
]

const activities = [
  { title: 'Adoption post published', meta: 'Milo is now visible to verified adopters', time: 'Today, 10:42 AM', tone: 'green', icon: Heart },
  { title: 'Missing pet alert saved', meta: 'Last seen near Dhanmondi Lake, Dhaka', time: 'Yesterday, 6:18 PM', tone: 'orange', icon: MapPin },
  { title: 'Monthly essentials delivered', meta: 'Your PetVerse order is on its way', time: 'Aug 24, 2026', tone: 'blue', icon: ShoppingBag },
]

export default function Page() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [menuOpen, setMenuOpen] = useState(false)
  const [showComposer, setShowComposer] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showSearch, setShowSearch] = useState(false)

  return (
    <main className="dashboard-app">
      <aside className={`dashboard-sidebar ${menuOpen ? 'open' : ''}`}>
        <div className="sidebar-top">
          <a className="brand" href="#top"><span className="brand-mark"><PawPrint size={17} /></span> petverse</a>
          <button className="sidebar-close" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={19} /></button>
        </div>
        <div className="workspace-switcher"><div className="avatar">AR</div><div><strong>Arif Rahman</strong><span>Pet parent</span></div><ChevronRight size={15} /></div>
        <nav className="dashboard-nav" aria-label="Dashboard navigation">
          <span className="nav-label">Workspace</span>
          {navItems.map(({ label, icon: Icon }) => <button key={label} className={activeNav === label ? 'active' : ''} onClick={() => { setActiveNav(label); setMenuOpen(false) }}><Icon size={17} /><span>{label}</span>{label === 'Community posts' && <small>2</small>}</button>)}
          <span className="nav-label secondary">Support</span>
          <button><CircleHelp size={17} /><span>Help center</span></button>
        </nav>
        <div className="sidebar-footer"><div className="trust-mini"><ShieldCheck size={17} /><div><strong>Trusted community</strong><span>Verified profiles and safer handovers.</span></div></div><button className="settings-link">Account settings <ChevronRight size={14} /></button></div>
      </aside>

      <section className="dashboard-main" id="top">
        <header className="dashboard-header"><button className="mobile-menu-button" onClick={() => setMenuOpen(true)} aria-label="Open menu"><Menu size={21} /></button><div className="breadcrumbs"><span>PetVerse</span><ChevronRight size={14} /><strong>{activeNav}</strong></div><div className="header-tools"><button className="search-control" onClick={() => setShowSearch(true)} aria-label="Search your workspace"><Search size={17} /><span>Search your workspace</span><kbd>⌘ K</kbd></button><button className="notification-button" onClick={() => setShowNotifications(!showNotifications)} aria-label="Notifications"><Bell size={18} /><i /></button><div className="header-avatar">AR</div>{showNotifications && <div className="notification-popover"><strong>Notifications</strong><p><Heart size={14} /> Someone saved Milo&apos;s adoption post.</p><p><ShieldCheck size={14} /> Your profile is verified.</p></div>}</div></header>

        <div className="dashboard-content">
          <div className="welcome-row"><div><p className="dashboard-kicker">Tuesday, September 9, 2026</p><h1>Good morning, Arif.</h1><p className="welcome-copy">Everything your pets need, all in one calm place.</p></div><button className="primary-action" onClick={() => setShowComposer(true)}><Plus size={17} /> Create a post</button></div>

          <section className="pet-profile-card"><div className="pet-profile-photo"><img src="https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=500&q=85" alt="Milo the golden dog" /></div><div className="pet-profile-details"><span className="status-pill"><i /> Profile active</span><h2>Milo <span>•</span> Golden Retriever</h2><p><CalendarDays size={15} /> 3 years old <span className="detail-divider" /> <MapPin size={15} /> Uttara, Dhaka</p><div className="pet-tags"><span>Friendly</span><span>Vaccinated</span><span>House trained</span></div></div><button className="ghost-action">View profile <ChevronRight size={15} /></button></section>

          <div className="metrics-grid"><div className="metric-card"><span className="metric-icon green"><Heart size={17} /></span><div><strong>24</strong><span>Post saves</span></div><small>+8 this week</small></div><div className="metric-card"><span className="metric-icon orange"><MapPin size={17} /></span><div><strong>1</strong><span>Active alert</span></div><small>Needs attention</small></div><div className="metric-card"><span className="metric-icon blue"><ShoppingBag size={17} /></span><div><strong>৳2,480</strong><span>Last order</span></div><small>Delivered Aug 28</small></div></div>

          <div className="dashboard-columns"><section className="activity-panel panel"><div className="panel-heading"><div><span className="panel-kicker">Your activity</span><h2>Recent updates</h2></div><button className="view-all">View all <ChevronRight size={14} /></button></div><div className="activity-list">{activities.map(({ title, meta, time, tone, icon: Icon }) => <article className="activity-item" key={title}><span className={`activity-icon ${tone}`}><Icon size={17} /></span><div><strong>{title}</strong><p>{meta}</p><small>{time}</small></div><ChevronRight size={16} /></article>)}</div></section><aside className="side-stack"><section className="reminder-card panel"><div className="reminder-top"><span className="panel-kicker">Coming up</span><CalendarDays size={18} /></div><h3>Vet visit reminder</h3><p>Milo&apos;s annual vaccination is due in 12 days.</p><button className="text-action">Add to calendar <ChevronRight size={14} /></button></section><section className="shop-card panel"><div><span className="panel-kicker">For Milo</span><h3>Keep his favourites<br />close at hand.</h3><button className="text-action">Shop essentials <ChevronRight size={14} /></button></div><img src="https://images.unsplash.com/photo-1589924691995-400dc9ecc119?auto=format&fit=crop&w=500&q=85" alt="Pet food bowl and kibble" /></section></aside></div>

          <section className="quick-start"><div><Sparkles size={19} /><div><span className="panel-kicker">Make a difference</span><h2>What would you like to do today?</h2></div></div><div className="quick-actions"><button onClick={() => setShowComposer(true)}><span className="quick-icon peach"><Heart size={18} /></span><span><strong>List for adoption</strong><small>Help a pet find home</small></span><ChevronRight size={15} /></button><button onClick={() => setShowComposer(true)}><span className="quick-icon yellow"><MapPin size={18} /></span><span><strong>Report a missing pet</strong><small>Alert your local community</small></span><ChevronRight size={15} /></button><button onClick={() => setShowComposer(true)}><span className="quick-icon blue"><FilePlus2 size={18} /></span><span><strong>Post a listing</strong><small>Buy or sell responsibly</small></span><ChevronRight size={15} /></button></div></section>
        </div>
      </section>

      {showSearch && <div className="overlay" onClick={() => setShowSearch(false)}><section className="search-modal" role="dialog" aria-modal="true" aria-labelledby="search-title" onClick={(event) => event.stopPropagation()}><button className="modal-x" onClick={() => setShowSearch(false)} aria-label="Close search"><X size={19} /></button><span className="panel-kicker">Workspace search</span><h2 id="search-title">Find anything in PetVerse.</h2><div className="search-input"><Search size={18} /><input autoFocus placeholder="Search pets, posts, orders..." aria-label="Search pets, posts, and orders" /></div><div className="search-suggestions"><span>Quick links</span><button onClick={() => { setShowSearch(false); setActiveNav('My pets') }}>My pets <ChevronRight size={14} /></button><button onClick={() => { setShowSearch(false); setActiveNav('Community posts') }}>Community posts <ChevronRight size={14} /></button><button onClick={() => { setShowSearch(false); setActiveNav('Shop PetVerse') }}>Shop PetVerse <ChevronRight size={14} /></button></div></section></div>}{showComposer && <div className="overlay" onClick={() => setShowComposer(false)}><section className="composer-modal" role="dialog" aria-modal="true" aria-labelledby="composer-title" onClick={(event) => event.stopPropagation()}><button className="modal-x" onClick={() => setShowComposer(false)} aria-label="Close"><X size={19} /></button><span className="panel-kicker">Create something helpful</span><h2 id="composer-title">What would you like to post?</h2><p>Choose a post type to get started. You can add photos, details, and a location next.</p><div className="composer-options"><button onClick={() => setShowComposer(false)}><Heart size={18} /><span><strong>Adoption post</strong><small>Find a caring home for a pet</small></span><ChevronRight size={15} /></button><button onClick={() => setShowComposer(false)}><MapPin size={18} /><span><strong>Missing pet alert</strong><small>Tell your community where they were last seen</small></span><ChevronRight size={15} /></button><button onClick={() => setShowComposer(false)}><ShoppingBag size={18} /><span><strong>Marketplace listing</strong><small>Buy or sell with clear, honest details</small></span><ChevronRight size={15} /></button></div></section></div>}
    </main>
  )
}
